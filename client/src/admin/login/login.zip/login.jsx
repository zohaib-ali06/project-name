import React from 'react';
import './login.css';
import {  useNavigate, Redirect } from 'react-router-dom';


const Login = () => {
    const navigate=useNavigate();

  const  handleSubmit = (event) => {
        event.preventDefault();
        const Email =event.target.Email.value;
        const Password =event.target.Password.value;
        console.log(event.target.Email.value)          // or directly
        console.log(event.target.Password.value)          // or directly

        if(Email=='zohaibali935@gmailcom' && Password=='zohaib123'){
          
            navigate('/admin/login');
        }
      };
  return (
    <div className='main-content'>

 
<div className="container">
      <form onSubmit={handleSubmit}>
   
      <div className="inputs">
        <label>Email</label>
        <input type="text" placeholder="Email" name='Email' />
       <div classNameName="bg_color">
        <label>Password</label>
        <input type="input" placeholder='Password' name='Password' />
       </div>
         
         <button type="submit" className="sub_btn" >Submit</button>
      </div>
    </form>
    </div>
  

    </div>
  )
}

export default Login